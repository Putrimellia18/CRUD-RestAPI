﻿using CRUDAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace CRUDAPI.Repository
{
    public class UserRepo : IUserRepo
    {
        private readonly AppDbContext _context;

        public UserRepo(AppDbContext context)
        {
            _context = context;
        }
        public async Task Create(User user)
        {
            if (user != null)
            {
                await _context.AddAsync(user);
            }
            else
            {
                throw new ArgumentNullException(nameof(user));
            }
        }

        void IUserRepo.Delete(User id)
        {
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            _context.Users.Remove(id);
        }

        public IList<User> GetAll()
        {
            var data = _context.Users.ToList();
            return data;
        }

        public User GetById(int id)
        {
            var data = _context.Users.FirstOrDefault(c => c.id==id);
            return data;
        }

        public async Task SaveChange()
        {
           await _context.SaveChangesAsync();
        }
    }
}
