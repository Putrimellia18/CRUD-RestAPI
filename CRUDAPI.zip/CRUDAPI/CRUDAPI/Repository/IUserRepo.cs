﻿using CRUDAPI.Models;

namespace CRUDAPI.Repository
{
    public interface IUserRepo
    {
        Task SaveChange();
        User GetById(int id);
        IList<User> GetAll();
        Task Create(User user);
        void Delete(User id);

    }
}
