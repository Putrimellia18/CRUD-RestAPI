﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure.Internal;

namespace CRUDAPI.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext (DbContextOptions options) : base(options) 
        {

        }
        public DbSet<User> Users { get; set; }
    }
}
