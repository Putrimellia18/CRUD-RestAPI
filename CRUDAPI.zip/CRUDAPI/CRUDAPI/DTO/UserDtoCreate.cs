﻿namespace CRUDAPI.DTO
{
    public class UserDtoCreate
    {
        public string name { get; set; }
        public string email { get; set; }
        public string password { get; set; }
    }
}
