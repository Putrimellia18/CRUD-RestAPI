﻿using AutoMapper;
using CRUDAPI.DTO;
using CRUDAPI.Models;
using CRUDAPI.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserRepo repo;
        private readonly IMapper mapper;
        public UserController(IUserRepo userRepo, IMapper mapper)
        {
            this.repo = userRepo;
            this.mapper = mapper;
        }
        [HttpGet]
        public ActionResult<IList<UserDtoRead>> GetUser() 
        {
            var command = repo.GetAll();
            //Results.Ok(command);    
            return Ok(mapper.Map<IList<UserDtoRead>>(command));
        }
        [HttpGet("{id}")]
        public ActionResult<UserDtoRead> GetUserById(int id)
        {
            var command = repo.GetById(id);
            if (command != null)
            {
                return Ok(command);

            }
            return NotFound();

        }
        [HttpPost]
        public async Task<CreatedResult> createUser(UserDtoCreate userCreate)
        {
            var command = mapper.Map<User>(userCreate);
            await repo.Create(command);
            await repo.SaveChange();

            var success = mapper.Map<UserDtoRead>(command);
            return Created($"api/User/{success.id}", success);
        }
        [HttpPut]
        public ActionResult<UserDtoRead> UpdateUser(UserDtoUpdate userUpdate)
        {
            var command = repo.GetById(userUpdate.id);
            if(command != null) 
            { 
                mapper.Map(userUpdate,command);
                repo.SaveChange();
                return Ok(command);
            }
            return NotFound();
        }
        [HttpDelete("{id}")]
        public ActionResult DeleteUser(int id)
        {
            var command = repo.GetById(id);
            if (command!=null)
            {
                repo.Delete(command);
                repo.SaveChange() ;
                return Ok();
            }
            return NotFound();
        }
    }
}
