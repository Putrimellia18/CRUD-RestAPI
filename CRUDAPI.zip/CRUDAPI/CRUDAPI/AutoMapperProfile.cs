﻿using AutoMapper;
using CRUDAPI.DTO;
using CRUDAPI.Models;

namespace CRUDAPI
{
    public class AutoMapperProfile :Profile
    {
        public AutoMapperProfile() 
        {
            CreateMap<UserDtoRead,User>().ReverseMap();
            CreateMap<UserDtoCreate, User>()
                .ForMember(x=> x.name, opt=>opt.MapFrom(src=>src.name))
                .ForMember(x => x.email, opt => opt.MapFrom(src => src.email))
                .ForMember(x => x.password, opt => opt.MapFrom(src => src.password))
                .ReverseMap();
            CreateMap<UserDtoUpdate, User>().ReverseMap();

        }
    }
}
